/**
 * 
 */
package cs345felchs;

/**
 * @author felchs
 *
 */
public enum Event {
	INIT, MOVE, COMMAND, EXIT
}
