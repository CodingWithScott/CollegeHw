/**
 * 
 */
package cs345felchs;

/**
 * @author felchs
 *
 */
public class Room implements IRoom {
	
	private String name;
	private String desc; 	// Room description
	//private ArrayList<Path>

	// Default constructor, I don't think this will ever be used
	public Room() {
		this.name = "";
		this.desc = "";
		GameGlobals.allRooms.add(this);		// Add this object to master list of all Rooms stored in GameGlobals
	}
	
	// Constructor with arguments provided for name, description
	public Room(String name, String desc) {
		this.name = name;
		this.desc = desc;
		GameGlobals.allRooms.add(this);		// Add this object to master list of all Rooms stored in GameGlobals
	}
	
	public String getName() {
		return this.name;
	}
	/* (non-Javadoc)
	 * @see cs345felchs.IRoom#getDescription()
	 */
	@Override
	public String getDescription() {
		return this.desc;
	}
	


}
