/**
 * 
 */
package cs345felchs;

import java.util.*;
import static cs345felchs.GameGlobals.*;

/**
 * @author felchs
 *
 */
public class VocabTerm implements IVocabTerm {
	
	private String name;
	// The ArrayList will hold all the different possible names for an object
	private ArrayList<IWord> synonyms = new ArrayList<IWord>();
	
	// Default constructor 
	public VocabTerm() {
		this.name = null;
		// Don't touch synonyms here, it's already initialized!
		GameGlobals.allVocab.add(this);		// Add this object to master list of all VocabTerms stored in GameGlobals
	}
	
	// Constructor with a single string provided for a name
	public VocabTerm(String name) {
		this.name = name;
		//Don't touch synonyms here, it's already initialized!
		GameGlobals.allVocab.add(this);		// Add this object to master list of all VocabTerms stored in GameGlobals
	}

	/* (non-Javadoc)
	 * @see cs345felchs.IVocabTerm#addWord(cs345felchs.IWord)
	 */
	@Override
	public void addWord(IWord word) {
//		messageOut.println("Called addWord. Word is:  "); 
//		word.PrintName(); messageOut.println(" ");
		this.synonyms.add(word);
		messageOut.print("Added "); word.getName(); messageOut.print(" to v" + this.name + "\n"); 
	}
	
	public String getName() {
		return ("v" + this.name); 
	}
	
	public void printWords() {
		// Loop that will go through and print each Word in the VocabTerm
		messageOut.println("Printing contents of " + this.name + ":  ");
		
		for (int i = 0; i < synonyms.size(); i++) {
			this.synonyms.get(i).getName();
		}
	}
	
}