package cs345felchs;



public class Path {	
	// Each Path object is going to have a VocabTerm (ex: "go"), a Room coming from (implicit from Player's location), and a Room going to
	private VocabTerm vocab;
	private Room from;
	private Room to;
	
	// Default constructor
	public Path() {
		this.vocab = null;
		this.from = null;
		this.to = null;
	}
	
	// Constructor accepting a VocabTerm, Room coming from, and Room going to
	public Path(VocabTerm vocab, Room from, Room to) {
		this.vocab = vocab;
		this.from = from;
		this.to = to;
	}
	
	public VocabTerm getVocabTerm() {
		return this.vocab;
	}
	
	public Room getFrom() {
		return this.from;
	}
	
	public Room getTo() {
		return this.to;
	}
	
}
