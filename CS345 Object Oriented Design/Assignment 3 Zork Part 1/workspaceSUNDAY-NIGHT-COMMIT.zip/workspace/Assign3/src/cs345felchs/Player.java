/**
 * 
 */
package cs345felchs;

/**
 * @author felchs
 *
 */
public class Player implements IPlayer {

	/* (non-Javadoc)
	 * @see cs345felchs.IPlayer#getLocation()
	 */
	@Override
	public IRoom getLocation() {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see cs345felchs.IPlayer#apportTo(cs345felchs.IRoom)
	 */
	@Override
	public void apportTo(IRoom room) {
		// TODO Auto-generated method stub

	}

	/* (non-Javadoc)
	 * @see cs345felchs.IPlayer#startAt(cs345felchs.IRoom)
	 */
	@Override
	public void startAt(IRoom room) {
		// TODO Auto-generated method stub

	}

	/* (non-Javadoc)
	 * @see cs345felchs.IPlayer#moveOnPath(cs345felchs.IWord)
	 */
	@Override
	public void moveOnPath(IWord pathName) {
		// TODO Auto-generated method stub

	}

	/* (non-Javadoc)
	 * @see cs345felchs.IPlayer#lookAround()
	 */
	@Override
	public void lookAround() {
		// TODO Auto-generated method stub

	}

}
